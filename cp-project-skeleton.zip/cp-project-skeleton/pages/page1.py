"""pages/page1.py — ★ your page 1.

Pick a page type from catalog/ (list, form, detail, search, stats, ranking, calculator, cart, gallery, text),
copy its page.py over this file and its page.html over templates/page1.html, then adapt.
Ask Copilot:  /new-page
"""
import storage

TITLE = "Page 1"


def build():
    # TODO: read data with storage.load(), work on it, return a dict for the template
    raise NotImplementedError("page1")
